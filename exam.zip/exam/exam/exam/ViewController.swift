//
//  ViewController.swift
//  exam
//
//  Created by Student on 16/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    @IBOutlet weak var segout: UISegmentedControl!
    @IBAction func seg(_ sender: Any) {
        var value = segout.selectedSegmentIndex
        
        if value == 1  {
            performSegue(withIdentifier: "toemployee", sender: self)
        }
        
    }
    
    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var txt3: UITextField!
    
    @IBOutlet weak var lable: UILabel!
    
    @IBAction func calaction(_ sender: Any) {
        let result = (Float(txt1.text!)! + Float(txt2.text!)! + Float(txt3.text!)!) / 3
        lable.text = String(result)
    }
    
}

