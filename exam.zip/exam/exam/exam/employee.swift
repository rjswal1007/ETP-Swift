//
//  employee.swift
//  exam
//
//  Created by Student on 16/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class employee: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        btnout.layer.cornerRadius = 15

        // Do any additional setup after loading the view.
    }
    

    
    @IBOutlet weak var lable: UILabel!
    
    @IBOutlet weak var txtout: UITextField!
    
    @IBOutlet weak var btnout: UIButton!
    
    @IBAction func btn(_ sender: Any) {
        let result = Float(txtout.text!)!
        if result <= 3000000{
            lable.text = "No tax"
            
        }
        else{
            lable.text = "Pay tax"
        }
    }
    
    
    
    
    
    
    
}
